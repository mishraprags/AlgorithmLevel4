
// Author Pragati Mishra
//2506109m
import java.util.*;

/**
 * The Class Algorithm, containing methods to run either the RGS algorithm
 * for HR or Király's algorithm for HRT, to print the matching and to check
 * the matching for stability
 */
public class Algorithm {

	/** The HR instance */
	private Instance instance;

	/**
	 * Instantiates a new Algorithm object
	 * @param instance the HR/HRT instance
	 */
	public Algorithm (Instance instance) {
		this.instance = instance;
	}

	/**
	 * Executes Király's algorithm for HR
	 */
	public void run() {
		Stack<Doctor> unassignedDoctors = new Stack<Doctor>();
		Doctor [] doctors = instance.getAllDoctors();
		//loop for pushing doctors to the stack of unassigned doctors
		//Followed by while loop which will check if unassigneddoctors stack is not empty 
		// There is while loop within the loop and within that loop, we check if hospital is undersubscribed or not and if condition satisfies
		// it will assign some hospital to that doctor according to the preference
		// If condition doesn't satisy then we need to calculate worst rank and current rank that can be calculated using getRankofWorstAssignee and getRank which 
		//have been introduced in the hospital.java
		// Now we will be having worst rank and current rank , through which we can check if the current rank is greater than the next worstrank 
		// If that condition satisfies then we can just push that particular worst assigneee that has been unassigned to unassigneddoctors' list
	

		for (int i = doctors.length - 1; i >= 0; i--){
			unassignedDoctors.push(doctors[i]);
			doctors[i].setIterator();
		}
		
		while (!unassignedDoctors.isEmpty()) {
			
			Doctor doctor = unassignedDoctors.pop();
			Iterator<Hospital> hospitalIterator = doctor.getIterator();
			while (hospitalIterator.hasNext()) {
				Hospital hospital = hospitalIterator.next();
				if (hospital.isUnderSubscribed()) {
					doctor.assignTo(hospital);
					hospital.incrementNumAssignees();
					break;
				} else { 
					int worstRank = hospital.getRankOfWorstAssignee();
					int currentRank = hospital.getRank(doctor);
					if (worstRank+1 > currentRank) {
						Doctor worstAssignee = hospital.getPreferenceList().get(worstRank);
						worstAssignee.unassign();
						unassignedDoctors.push(worstAssignee);
						doctor.assignTo(hospital);
						
					}}}
				}
			}
		
	

	/**
	 * Prints the matching to the console
	 */
	public void printMatching() {
		// to be completed for Task 1
		int value = 0;
		Doctor [] doctors = instance.getAllDoctors();
		System.out.println("Matching:");
		for (Doctor d : doctors) {
			// if the doctor is not assigned anywhere, she is unmatched
			if (d.getAssignment() == null) {
				System.out.println("Doctor " + d.getId() + " is unmatched");
			} else {
				// this incremental operator is used to get the exact number of matching instances within the loop that would be used for rthe algorithm 
				value++;
				System.out.println("Doctor " + d.getId() + " is assigned to hospital " + d.getAssignment());
			}
		} System.out.println("Matching size: " + value);
		
	}

	/**
	 * Checks the matching for stability
	 */
	public void checkStability() {
		// to be completed for Task 4
		boolean isStable = true;
		Doctor [] doctors = instance.getAllDoctors();
		List<Hospital> hospitals = new ArrayList<Hospital>();
		for (Doctor d : doctors) {
			Hospital assignment = d.getAssignment();
			if (assignment != null) {
				hospitals = d.getPreferenceList().subList(0,d.getPreferenceList().indexOf(assignment));
			} else {
				hospitals = d.getPreferenceList();
			}
			for (Hospital h : hospitals){
				if (h.getRankOfWorstAssignee()+1 > h.getRank(d)){
					isStable = false;
					System.out.println("Blocking pair between doctor " + d.getId() + " and hospital " + h.getId());
				}
			}
		}
		if (isStable){
			System.out.println("Matching is stable");
		} else {
			System.out.println("Matching is not stable");
		}
	}

	/**
	 * Determines whether we have a valid matching
	 * @return true if we have a valid matching, false otherwise
	 */
	public boolean checkMatching() {
		// get all doctors and hospitals
		Doctor [] doctors = instance.getAllDoctors();
		Hospital [] hospitals = instance.getAllHospitals();
		// reset number of assignees of each hospital to 0
		for (Hospital h : hospitals)
			h.resetNumAssignees();
		// iterate over each doctor in turn
		for (Doctor d : doctors) {
			// check if d is assigned
			if (d.getAssignment() != null) {
				// get hospital h that d is assigned to
				Hospital h = d.getAssignment();
				// determine whether h finds d acceptable
				if (h.getRank(d) < 0) {
					// h finds d unacceptable, matching invalid
					System.out.println("Hospital "+h.getId()+" does not find doctor "+d.getId()+" acceptable!");
					return false;
				}
				// d is a legal assignee of h
				h.incrementNumAssignees();
			}
		}
		// check whether a hospital is oversubscribed
		for (Hospital h : hospitals)
			if (h.isOverSubscribed()) {
				System.out.println("Hospital "+h.getId()+" is oversubscribed!");
				return false;
			}
		// we have a valid matching
		return true;
	}
}
