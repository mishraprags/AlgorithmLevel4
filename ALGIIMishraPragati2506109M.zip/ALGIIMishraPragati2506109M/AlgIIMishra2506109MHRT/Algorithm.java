// Author 2506109M
// Pragati Mishra

import java.util.*;

/**
 * The Class Algorithm, containing methods to run either the RGS algorithm
 * for HR or Király's algorithm for HRT, to print the matching and to check
 * the matching for stability
 */
public class Algorithm {

	/** The HRT instance */
	private Instance instance;

	/**
	 * Instantiates a new Algorithm object
	 * @param instance the HR/HRT instance
	 */
	public Algorithm (Instance instance) {
		this.instance = instance;
	}

	/**
	 * Executes RGS algorithm for HRT
	 */
	public void run() {
		Stack<Doctor> unassignedDoctors = new Stack<Doctor>();
		Doctor [] doctors = instance.getAllDoctors();
		for (int i = doctors.length - 1; i >= 0; i--){
			unassignedDoctors.push(doctors[i]);
			doctors[i].setIterator();
		}
		// while loop to make sure if there are doctors that need to be assigned from the initialised stack 
		while (!unassignedDoctors.isEmpty()) {
			Doctor doctor = unassignedDoctors.pop();
			Iterator<Hospital> hospitalIterator = doctor.getIterator();
			// checking second condition: if there are hospitals left in the doctor's preference list
			// other loop to make sure if there are hospitals left in doctor's preference list and created methods 
			//setExhausted
			//setPromoted
			//both are assigned as false
			while ((!doctor.isPromoted() || !doctor.isExhausted()) && hospitalIterator.hasNext()) {
				if (doctor.isExhausted()){
					doctor.setExhausted(false);
					doctor.setPromoted(true);
					doctor.setIterator();
				}
				//Now considering RGS HRT Algorithm, through this I could access first preference object from the list 
				//assign or unassign it accordingly.
				//  isUnderSubscribere is again the method 
				// Determines whether hospital is under-subscribed return true if hospital is under-subscribed, false otherwise
				// After checking for the condition, we can assign doctors to hospitals and directly create a matching if condition satisfies.
				//if doesn't satisfies then we can find the worst assigned doctor from the hospital and getting rank which could
				// be used to compare the prev ious assignee to the rank of current doctor
				Hospital hospital = hospitalIterator.next();
				if (hospital.isUnderSubscribed()) {
					doctor.assignTo(hospital);
					hospital.incrementNumAssignees();
					break;
				} else { 
					int worstRank = hospital.getRankOfWorstAssignee();
					int currentRank = hospital.getRank(doctor);
					Doctor worstAssignee = hospital.getWorstAssignee();
					if (worstRank +1 > currentRank || (worstRank+1 == currentRank && !worstAssignee.isPromoted() && doctor.isPromoted())) { 
						worstAssignee.unassign(hospital);
						unassignedDoctors.push(worstAssignee);
						doctor.assignTo(hospital);
						break;
					}
				}
				if (doctor.getAssignment() != doctor.getPreferenceList().get(doctor.getPreferenceList().size()-1)){
					doctor.setExhausted(true);
				}
			}
		}
	}

	/**
	 * Prints the matching to the console
	 */
	public void printMatching() {
		// to be completed for Task 1
		int count = 0;
		Doctor [] doctors = instance.getAllDoctors();
		System.out.println("Matching:");
		for (Doctor d : doctors) {
			if (d.getAssignment() == null) {
				System.out.println("Doctor " + d.getId() + " is unmatched");
			} else {
				count++;
				System.out.println("Doctor " + d.getId() + " is assigned to hospital " + d.getAssignment());
			}
		}
		System.out.println("Matching size: " + count);
	}

	/**
	 * Checks the matching for stability
	 */

	public void checkStability() {
	// to be completed for Task 4
		// isStable true if there are no blocking pairs found
		boolean isStable = true;
		Doctor [] doctors = instance.getAllDoctors();
		List<Hospital> hospitals;
		for (Doctor d : doctors) {
			// getting the assignment for the current doctor
			Hospital assignment = d.getAssignment();
			// if the doctor is assigned
			if (assignment != null) {
				// slicing the preference list of the doctor until the current doctor's assigned hospital,
				// so that we can check whether there are doctors of smaller rank that
				// she could have been assigned too (i.e. whether there are blocking pairs)
				hospitals = d.getPreferenceList().subList(0,d.getPreferenceList().indexOf(assignment));
			} else {
				hospitals = d.getPreferenceList();
			}
			for (Hospital h : hospitals){
				// checking for blocking pairs
				if (h.getRankOfWorstAssignee()+1 > h.getRank(d)){
					// we found a blocking pair, so we set isStable to false
					isStable = false;
					System.out.println("Blocking pair between doctor " + d.getId() + " and hospital " + h.getId());
				}
			}
		}
		if (isStable){
			System.out.println("Matching is stable");
		} else {
			System.out.println("Matching is not stable");
		}
	} 
	/**
	 * Determines whether we have a valid matching
	 * @return true if we have a valid matching, false otherwise
	 */
	public boolean checkMatching() {
		// get all doctors and hospitals
		Doctor [] doctors = instance.getAllDoctors();
		Hospital [] hospitals = instance.getAllHospitals();
		// reset number of assignees of each hospital to 0
		for (Hospital h : hospitals)
			h.resetNumAssignees();
		// iterate over each doctor in turn
		for (Doctor d : doctors) {
			// check if d is assigned
			if (d.getAssignment() != null) {
				// get hospital h that d is assigned to
				Hospital h = d.getAssignment();
				// determine whether h finds d acceptable
				if (h.getRank(d) < 0) {
					// h finds d unacceptable, matching invalid
					System.out.println("Hospital "+h.getId()+" does not find doctor "+d.getId()+" acceptable!");
					return false;
				}
				// d is a legal assignee of h
				h.incrementNumAssignees();
			}
		}
		// check whether a hospital is oversubscribed
		for (Hospital h : hospitals)
			if (h.isOverSubscribed()) {
				System.out.println("Hospital "+h.getId()+" is oversubscribed!");
				return false;
			}
		// we have a valid matching
		return true;
	}
}
